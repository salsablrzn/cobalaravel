<!DOCTYPE html>
<head>
 <title>Belajar Laravel</title>
</head>
<body>
 <header>
 <nav>
 <a href="/home">Home</a>
 <a href="/tentang">Tentang</a>
 </nav>
 </header>

 <hr>
 <br>
 <!-- Judul halaman -->
 <h2><?php echo $__env->yieldContent('judul'); ?></h2>
 <!-- konten halaman -->
 <?php echo $__env->yieldContent('konten'); ?>
 <br>
 <footer>
 <p>Percobaan membuat halaman dengan template</p>
 </footer>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/master.blade.php ENDPATH**/ ?>