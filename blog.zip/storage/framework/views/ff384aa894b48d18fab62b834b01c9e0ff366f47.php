<?php $__env->startSection('konten'); ?>
<!-- form start -->
              <h3> &nbsp;&nbsp;Edit User</h3>
                <form class="form-horizontal form-label-left" action="UserUpdate" method="post">
                   <?php echo e(@csrf_field()); ?>

                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputUserID">User ID<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter User ID" id="userid" name="userid" value=" <?php echo e($user->User_ID); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputFirstName">First Name<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter First Name" id="userid" name="firstname" value=" <?php echo e($user->First_Name); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputLastName">Last Name<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Last Name" id="userid" name="lastname" value=" <?php echo e($user->Last_Name); ?>">
                  </div>

				<div class="form-group">
                    <label for="exampleInputEmail">Email<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Email" id="userid" name="email" value=" <?php echo e($user->Email); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputPhone">Phone<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Phone" id="userid" name="phone" value=" <?php echo e($user->Phone); ?>">
                  </div>

                  
                  <div class="form-group">
                    <label for="exampleInputPassword">Password<span class="required"> * </span></label>
                    <input class="form-control" type="password" placeholder="Enter Password" id="userid" name="password" value=" <?php echo e($user->Password); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputJobStatus">Job Status<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Job Status" id="userid" name="jobstatus" value=" <?php echo e($user->Job_Status); ?>">
                  </div>

                  <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree to the</label>
                    
                    <br>
                  </div>

                    <!-- /.card-body -->
              </div>
                <div class="card-footer">
                	<button type="submit" class="btn btn-primary"><a href="CategoriesIndex" style="color: white;">Cancel</button>
                	<button type="submit" class="btn btn-primary">Update Data</button>
                  
                </div>
        </form>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/master/User/edit.blade.php ENDPATH**/ ?>