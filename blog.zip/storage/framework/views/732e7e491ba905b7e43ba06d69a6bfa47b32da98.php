<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="contrainer">
		<p>Destroy Categories</p>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/master/destroy.blade.php ENDPATH**/ ?>