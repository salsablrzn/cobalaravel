<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">POINT OF SALES</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="col-lg-12">
<div class="block margin-bottom-sm">
	<table width="100%">
		<thead>
		<th><label class="col-sm-form-control-label">Auto ID</label>
			<div class="col-lg-5">
		<label for="inlineFormInput" class="sr-only">Name</label>
		<input id="inlineFormInput" type="text" disabled="" placeholder="Category ID" class="mr-sm-3 form-control"></th>
		</div>
		<th><label class="col-sm-form-control-label">Category Name</label>
		<div class="col-sm-5">
		  	<select class="form-control mb-3 mb-3" name="categoriesid">
                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                     
                      <option value=" <?php echo e($C->Category_ID); ?>">
                        <?php echo e($C->Category_Name); ?>

                      </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
		</thead>
	</table>
	  <button class="button" data-toggle="modal" data-target="#myModal" >Pilih Product</button>
	<br>
	<br>
	<table id="keranjang" width="100%" cellpadding="10px" bordercolorlight="#E8A7A8" border="2"> 
		<thead>
			<th width="295">Product Name</th>
			<th width="45">Qty</th>
			<th width="212">Price</th>
			<th width="228">Sub Total</th>
			<th width="228">Action</th>
		<tbody>
		</tbody>
	</table>
	
  </div>

<div class="row">
<div class="col-lg-8">
	<div class="block margin-bottom-sm">
		<label class="col-sm-form-control-label">Sub Total</label>
		<input id="subtotal-val" type="text" disabled="" placeholder="Rp. 10.000" class="mr-sm-3 form-control">
		<label class="col-sm-form-control-label">Pajak</label>
		<input id="pajak" type="text" disabled="" placeholder="10%" class="mr-sm-3 form-control">
		<label class="col-sm-form-control-label">Discount</label>
		<input id="discount" type="text" placeholder="0" class="mr-sm-3 form-control" oninput="total()">
	</div>
</div>

<div class="col-lg-4">
	<div class="block margin-bottom-sm">
		<label class="col-sm-form-control-label">Total</label>
		<input id="total-val" type="text" disabled="" placeholder="Rp. 10.000" class="mr-sm-3 form-control">
	</div>
</div>
</div>
</div>

<!-- Modal -->
  <div class="modal fade bd-example-modal-lg" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">          
          <h4 class="modal-title">Product</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
         <table>
         	<table width="100%" cellpadding="10px" bordercolorlight="#E8A7A8" border="2"> 
		<thead>
			<th width="295">Product ID</th>
			<th width="45">Category ID</th>
			<th width="212">Product Name</th>
			<th width="228">Product Price</th>
			<th width="228">Product Stock</th>
			<th width="228">Explanation</th>
		</thead>
		<tbody>
			<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PRO): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr onclick="pilihBarang(<?php echo e($PRO -> Product_ID); ?>)">
                      	<td><?php echo e($PRO -> Product_ID); ?> </td>
                        <td><?php echo e($PRO -> Category_ID); ?> </td>
                        <td><?php echo e($PRO -> Product_Name); ?> </td>
                        <td><?php echo e($PRO -> Product_Price); ?> </td>
                        <td><?php echo e($PRO -> Product_Stock); ?> </td>
                        <td><?php echo e($PRO -> Explanation); ?> </td>
                    </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
         </table>
        </div>
        
      </div>
    <!-- end of modal content -->                     
          </div>
        </div>
      </div>
</div>

<script>
	var barang = <?php echo json_encode($product); ?>;
	console.log(barang[0]["Product_Name"]);
	var colnum=0;

	function getVal(event){
		if (event.keyCode === 13) {
			modal();
		}
	}
	function pilihBarang(id){
		var index;
		for(var i=0;i<barang.length;i++){
			if(barang[i]["Product_ID"]==id){
				console.log(barang[i]);
				index=i;
				break;
			}
		}
		$("#myModal").modal("hide");

		var table = document.getElementById("keranjang");
		var row = table.insertRow(table.rows.length);
		row.setAttribute('id','col'+colnum);
		var id = 'col'+colnum;
		colnum++;

		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		var cell4 = row.insertCell(3);
		var cell5 = row.insertCell(4);
		console.log(index);
		cell1.innerHTML = '<input type="hidden" name="name[]" value="'+barang[index]["Product_Name"]+'">'+barang[index]["Product_Name"];
		cell2.innerHTML = '<input type="number" name="qty[]" value="1" oninput="recount('+barang[index]["Product_ID"]+')" id="qty'+barang[index]["Product_ID"]+'">';		
		cell3.innerHTML = '<input type="hidden" id="harga'+barang[index]["Product_ID"]+'" name="harga[]" value="'+barang[index]["Product_Price"]+'">'+barang[index]["Product_Price"];
		cell4.innerHTML = '<input type="hidden" class="subtotal" name="subtotal[]" value="'+barang[index]["Product_Price"]+'" id="subtotal'+barang[index]["Product_ID"]+'"><span id="subtotalval'+barang[index]["Product_ID"]+'">'+barang[index]["Product_Price"]+'</span>';
		cell5.innerHTML = '<button onclick="hapusEl(\''+index+'\')">Del</button>';

		total();
		
	}
	function lm(i){
		var min =  document.getElementById("qty"+i).value;
		if(min <= 1){

		}else{
		min--;
		document.getElementById("qty"+i).value = min;
		recount(i);
		}
	}
	function ln(i){
		var plus =  document.getElementById("qty"+i).value;
		console.log(plus);
		plus++;
		document.getElementById("qty"+i).value = plus;
		console.log(plus);
		recount(i);
	}
	function total(){
		var subtotals = document.getElementsByClassName("subtotal");
		var total = 0;
		for(var i=0; i<subtotals.length;++i){
			total += Number(subtotals[i].value); 
		}
		document.getElementById("subtotal-val").value = total;
		var disc = document.getElementById("discount").value;
		total = parseInt(110/100*total)-Number(disc);
		document.getElementById("total-val").value = total;

	}

	function recount(id){

		var price = document.getElementById("harga"+id).value;
		var sembarang = document.getElementById("qty"+id).value;

		var lego = Number(price*sembarang); 
		document.getElementById("subtotal"+id).value = lego;
		document.getElementById("subtotalval"+id).innerHTML = lego;
		total();
	}

	function modal(){
		$("#myModal").modal("show");
		document.getElementById("myText").value = "";
	}
	function hapusEl(idCol) {
		document.getElementById(idCol).remove();
		total();
	}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/transaksi/Pos/pos.blade.php ENDPATH**/ ?>