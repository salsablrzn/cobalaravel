<?php $__env->startSection('konten'); ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
        
           <!-- form start -->
              
                <h3> &nbsp;&nbsp;Form Category</h3>
                <form class="form-horizontal form-label-left" action="CategoriesStore" method="post">
                   <?php echo e(@csrf_field()); ?>

                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputNama">Category ID<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputCategoryID" type="text" placeholder="Enter Category ID" name="categoriesid">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputCategoryName">Category Name<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputCategoryName"type="text" placeholder="Enter Category Name" name="categoriesname">
                  </div>

                  <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree</a>.</label>
                    </div>
                    <br>
                    <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Cancel</button>
                	<button type="submit" class="btn btn-primary">Submit</button>
                  
                </div>
              </form>
            </div>
        
        </div>
      </div>

    </div>
              
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/master/Category/create.blade.php ENDPATH**/ ?>