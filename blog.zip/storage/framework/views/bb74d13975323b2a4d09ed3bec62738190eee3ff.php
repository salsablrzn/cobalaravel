<?php $__env->startSection('konten'); ?>
<!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Halaman Utama</h1>
            <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Download</a>
          </div>
          <center>
              <h1>SELAMAT DATANG</h1>
              <img class="img-fluid" src="selamatdatang.png" ></i>
            </center>
   </div>
 </div>
      <!-- End of Main Content -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/body.blade.php ENDPATH**/ ?>