<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="contrainer">
		<p>Crate SalesCategories</p>
	</div>

</body>
</html>