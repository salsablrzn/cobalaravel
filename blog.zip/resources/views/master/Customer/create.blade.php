@extends('admin/admin')
@section('konten')

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

          <!-- form start -->
              <h3> &nbsp;&nbsp;Form Customer</h3>
                <form class="form-horizontal form-label-left" action="CustomerStore" method="post">
                   {{ @csrf_field() }}
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputCustomerID">Customer ID<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputCustomerID"type="text" placeholder="Enter Customer ID" name="customerid">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputFirstName">First Name<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputFirstName"type="text" placeholder="Enter First Name" name="firstname">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputLastName">Last Name<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputLastName"type="text" placeholder="Enter Last Name" name="lastname">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputPhone">Phone<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputPhone"type="text" placeholder="Enter Phone" name="phone">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail">Email<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputEmail"type="text" placeholder="Enter Email" name="email">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputStreet">Street<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputStreet"type="text" placeholder="Enter Street" name="street">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputCity">City<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputCity"type="text" placeholder="Enter City" name="city">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputState">State<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputState"type="text" placeholder="Enter State" name="state">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputZipCode">Zip Code<span class="required"> * </span></label>
                    <input class="form-control" id="exampleInputZip Code"type="text" placeholder="Enter Zip Code" name="zipcode">
                  </div>

                  <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree.</label>
                    </div>
                    <br>
                  <!-- /.card-body -->
                </div>
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Cancel</button>
                  <button type="submit" class="btn btn-primary">Submit Data</button>
                  
                </div>
              </form>

  </div>
</div>
</div>
</div>
@endsection