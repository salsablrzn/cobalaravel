@extends('admin/admin')
@section('konten')
<!-- form start -->
              <h3> &nbsp;&nbsp;Edit Product</h3>
                <form class="form-horizontal form-label-left" action="ProductUpdate" method="post">
                   {{ @csrf_field() }}
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputProductID">Product ID<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product ID" id="productid" name="productid" value=" {{ $product->Product_ID }}">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputCategoryID">Category ID<span class="required"> * </span></label>
                    <select name="categoriesid">
                      @foreach($category as $C)
                       @if($C->Category_ID == $product->Category_ID) 
                      <option value=" {{ $C->Category_ID}}" selected>
                        {{ $C->Category_Name}}
                      </option>
                      @else
                      <option value=" {{ $C->Category_ID}}">
                        {{ $C->Category_Name}}
                      </option>
                      @endif
                      @endforeach
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductName">Product Name<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Name" id="productid" name="productname" value=" {{ $product->Product_Name }}">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductPrice">Product Price<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Price" id="productid" name="productprice" value=" {{ $product->Product_Price }}">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductStock">Product Stock<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Stock" id="productid" name="productstock" value=" {{ $product->Product_Stock }}">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputExplanation">Explanation<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Explanation" id="productid" name="explanation" value=" {{ $product->Explanation }}">
                  </div>

                  <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree to the</label>
                    
                    <br>
                  </div>

                    <!-- /.card-body -->
              </div>
                <div class="card-footer">
                	<button type="submit" class="btn btn-primary"><a href="CategoriesIndex" style="color: white;">Cancel</button>
                	<button type="submit" class="btn btn-primary">Update Data</button>
                  
                </div>
        </form>      

            @endsection