<!DOCTYPE html>
<head>
	<title>
		Belajar Laravel
	</title>
</head>
<body>
	<h3>
		Mengirim Data dari Controller ke View
	</h3>
	<br>
	<p>
		Menerima Data: {{ $nama }}
	</p>
</body>
</html>