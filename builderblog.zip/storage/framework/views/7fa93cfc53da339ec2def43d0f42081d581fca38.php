<!DOCTYPE html>
<head>
	<title>
		Belajar Laravel
	</title>
</head>
<body>
	<h3>
		Mengirim Data dari Controller ke View
	</h3>
	<br>
	<p>
		Menerima Data: <?php echo e($nama); ?>

	</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/showname.blade.php ENDPATH**/ ?>