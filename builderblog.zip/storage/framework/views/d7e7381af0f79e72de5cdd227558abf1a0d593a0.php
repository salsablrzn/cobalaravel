<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">POINT OF SALES</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>

<div class="col-lg-12">
<div class="block margin-bottom-sm">
	<!-- <table width="100%">
		<thead> -->

			<!-- form start -->
              
                <h3>Point Of Sales</h3>
                <!-- <div class="card-body"> -->
     
                <table width="35%">
                  <tr>
                  	<td>
                  		User Name : <?php echo e($sales->UFirst_Name); ?> <?php echo e($sales->ULast_Name); ?>

                  	</td>
                  </tr>

                  <tr>
                  	<td>
                  	Customer Name : <?php echo e($sales->First_Name); ?> <?php echo e($sales->Last_Name); ?>

                  </td>
              </tr>
              <tr>
              	<td>
              <h6>
              	Nota Date : <?php echo e($sales->Nota_Date); ?>

              </h6>
              </td>
              </tr>
              </table>
              <br>
	<table id="keranjang" width="100%" cellpadding="10px" bordercolorlight="#E8A7A8" border="2"> 
		<thead>
			<th width="228">ID</th>
			<th width="295">Product Name</th>
			<th width="45">Qty</th>
			<th width="45">Discount</th>
			<th width="212">Price</th>
			<th width="228">Sub Total</th>
			
		</thead>
		<tbody>
			 <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr id="col<?php echo e($loop->iteration); ?>">
        <td><?php echo e($salesdetail->Product_ID); ?></td>    
        <td><?php echo e($salesdetail->Product_Name); ?></td>
		<td><?php echo e($salesdetail->Quantity); ?></td>
		<td><?php echo e($salesdetail->Discount); ?></td>
		<td><?php echo e($salesdetail->Selling_Price); ?></td>
		<td><?php echo e($salesdetail->Total_price); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	<br>

<h4>
              	Total Payment : <?php echo e($sales->Total_Payment); ?>

              </h4>
</div>
</div>


          </div>
        </div>
      </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/transaksi/Pos/invoice.blade.php ENDPATH**/ ?>