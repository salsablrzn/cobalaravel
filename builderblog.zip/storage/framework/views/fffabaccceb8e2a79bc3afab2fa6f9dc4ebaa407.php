<?php $__env->startSection('konten'); ?>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">
        
           <!-- form start -->
              <h3> &nbsp;&nbsp;Edit Product</h3>
                <form class="form-horizontal form-label-left" action="ProductUpdate" method="post">
                   <?php echo e(@csrf_field()); ?>

                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputProductID">Product ID<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Auto Product ID" id="productid" name="productid" value=" <?php echo e($product->Product_ID); ?>" readonly>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputCategoryID">Category ID<span class="required"> * </span></label>
                    <br>
                    <select name="categoriesid" class="form-control mb-3 mb-3">
                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $C): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php if($C->Category_ID == $product->Category_ID): ?> 
                      <option value=" <?php echo e($C->Category_ID); ?>" selected>
                        <?php echo e($C->Category_Name); ?>

                      </option>
                      <?php else: ?>
                      <option value=" <?php echo e($C->Category_ID); ?>">
                        <?php echo e($C->Category_Name); ?>

                      </option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductName">Product Name<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Name" id="productid" name="productname" value=" <?php echo e($product->Product_Name); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductPrice">Product Price<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Price" id="productid" name="productprice" value=" <?php echo e($product->Product_Price); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputProductStock">Product Stock<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Product Stock" id="productid" name="productstock" value=" <?php echo e($product->Product_Stock); ?>">
                  </div>

                  <div class="form-group">
                    <label for="exampleInputExplanation">Explanation<span class="required"> * </span></label>
                    <input class="form-control" type="text" placeholder="Enter Explanation" id="productid" name="explanation" value=" <?php echo e($product->Explanation); ?>">
                  </div>

                  <div class="form-group">
                     <label for="exampleInputStatus">Status<span class="required"> * </span></label>
                     <br>
    <select name='status' class="form-control mb-3 mb-3">
    <?php if($product->Status==0): ?>
    <option selected value="0">Non Aktif</option>
    <option value='1'>Aktif</option>
    <?php else: ?>
    <option value="0">Non Aktif</option>
    <option selected value='1'>Aktif</option>
    <?php endif; ?>
    </select>
                  </div>
                  <!-- /.card-body -->
                </div>
                <div class="custom-control custom-checkbox">
                      <input type="checkbox" name="terms" class="custom-control-input" id="exampleCheck1">
                      <label class="custom-control-label" for="exampleCheck1">I agree.</label>
                    </div>
                    <br>
                  <!-- /.card-body -->
                </div>
                <center>
                <div class="card-footer">
                  <button type="submit" class="btn btn-danger">Cancel</button>
                  <button type="submit" class="btn btn-primary">Submit</button>
                  
                </div>
                </center>
              </form>

  </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/master/Product/edit.blade.php ENDPATH**/ ?>