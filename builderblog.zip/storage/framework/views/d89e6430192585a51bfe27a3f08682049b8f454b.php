<!DOCTYPE html>
<head>
	<title>
		Belajar Laravel
	</title>
</head>
<body>
	<h3>
		Percobaan Pertama View
	</h3>
	<p>
		Membuka Web Dari View!
	</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/webtest.blade.php ENDPATH**/ ?>