<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div class="contrainer">
		<p>Index SalesCategories</p>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/Transaksi/index.blade.php ENDPATH**/ ?>