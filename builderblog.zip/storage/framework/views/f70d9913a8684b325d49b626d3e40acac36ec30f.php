<!DOCTYPE html>
<html>
<head>
	<title>
	</title>
</head>
<body>
	<div class="contrainer">
		<p>Destroy SalesCategories</p>
	</div>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/Transaksi/destroy.blade.php ENDPATH**/ ?>