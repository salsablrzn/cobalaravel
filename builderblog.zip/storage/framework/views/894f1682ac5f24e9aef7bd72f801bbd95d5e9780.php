<!DOCTYPE html>
<html>
<head>
	<title>Customer</title>
</head>	
	
<form method="post" action="CustomerController.php">

 <center>
<h3>Input Data Customer</h3>
		
		<table>
			<tr>
				<td>ID Customer</td>
				<td><input type="text" name="ID_KURIKULUM" readonly=""></td>					
			</tr>
			<tr>
				<td>Nama Customer</td>
				<td><input type="text" name="Nama Customer" required=""></td>					
			</tr>

			
			<tr>
				<td></td>
				<td><input type="submit" class="button" value="Simpan" ></td>	
				<td><input type="submit" class="button" value="Lihat Semua Data" ></td>				
			</tr>				
		</table>
	</form>
	</center>
</body>
	<script>
		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))
 
		    return false;
		  return true;
		}
	</script>


</script>	
	
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/Customer/Customer.blade.php ENDPATH**/ ?>