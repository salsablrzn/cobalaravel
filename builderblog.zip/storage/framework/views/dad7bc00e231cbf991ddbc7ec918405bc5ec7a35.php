<!DOCTYPE html>
<html>
<head>
	<title>Menampilkan data dari database</title>
	<link rel="stylesheet" type="text/css" href="style_pbd.css">
</head>
<body>
	<div class="judul">		
		<h1>Create Data</h1>
	</div>
	<br/>
 		<a href="index2.php">Lihat Semua Data</a>
	<br/>
	
 <center>
<h3>Input Data Admin Baru</h3>
	 <form action="input-aksi.php" method="post" onSubmit="validasi()">		
		<table>
			<tr>
				<td>Id Admin</td>
				<td><input type="text" name="ID_ADMIN"></td>					
			</tr>
			<tr>
				<td>Nama Admin</td>
				<td><input type="text" name="NAMA_ADMIN"></td>					
			</tr>	
			<tr>
				<td>Alamat Admin</td>
				<td><input type="text" name="ALAMAT_ADMIN"></td>					
			</tr>	
			<tr>
				<td>No Telpon</td>
				<td><input type="text" maxlength="13" onKeyPress="return hanyaAngka(event)" name="NO_TELP_ADMIN"></td>
			</tr>	
			<tr>
				<td>Email Admin</td>
				<td><input type="email" name="EMAIL_ADMIN"></td>					
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td><input type="text" name="JK_ADMIN"></td>					
			</tr>
			<tr>
				<td>Status Admin</td>
				<td><select>
						<option nama="Status" value="Aktif">Aktif</option>
  						<option nama="Status" value="Non-Aktif">Non-Aktif</option>
					</select></td>					
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="button" value="Simpan" ></td>					
			</tr>				
		</table>
	</form>
	</center>
</body>
	<script>
		function hanyaAngka(evt) {
		  var charCode = (evt.which) ? evt.which : event.keyCode
		   if (charCode > 31 && (charCode < 48 || charCode > 57))
 
		    return false;
		  return true;
		}
	</script>

	</script>
	</title>
</head>
<body>

</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/master/create.blade.php ENDPATH**/ ?>